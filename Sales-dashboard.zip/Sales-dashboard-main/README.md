# Sales-dashboard
•Created a comprehensive Power BI dashboard to visualize and analyze sales data, including key metrics like sales by region, payment mode, segment, and shipping mode.<br>
•Utilized advanced charting and data visualization techniques to showcase sales trends, profit analysis, and sales forecasts, aiding in strategic decision-making.<br>
